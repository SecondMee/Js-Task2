let items = 0;
let store = localStorage.getItem("cartInfo");
let productQuant = [];

if (store === null) {
   	productQuant = Array(12).fill(0);
	localStorage.setItem("cartInfo",productQuant);
} else{
	let str = localStorage.getItem("cartInfo");
	let arrStr = str.split(',');
	for(let i=0; i<arrStr.length;i++){
		x = parseInt(arrStr[i]);
		items += x;
		productQuant.push(x);
	}
}

const countTop=document.getElementById("cartCount");
if(items>0)
countTop.innerHTML=items;

let cartBtnDisplay = localStorage.getItem("cartDisplay");
if(cartBtnDisplay==null){
	cartBtnDisplay="hide";
}
if(items==0)
	localStorage.setItem("cartDisplay","hide");


let val=0;


document.addEventListener('DOMContentLoaded', function(){
	const diff = document.querySelectorAll('.textBox');
	let count=0;
	diff.forEach(btn => {
			btn.value=productQuant[val];
			val++;
			if(btn.value>0){
				const btn = document.getElementById(`p${val}`).childNodes[7].childNodes[1];
				btn.disabled=false;
				count++;
			}
	});
	if(count>0)
	computeTotal();

	let overlay = localStorage.getItem('overlay');
	if(overlay)
	document.getElementById('overlay').style.display=overlay;
	else
	localStorage.setItem('overlay','none');


	let cartBtn = localStorage.getItem('cartStatus');
	if(cartBtn==null)
		localStorage.setItem('cartStatus','deactivated');
	
});

document.addEventListener('DOMContentLoaded',function(){
	if(cartBtnDisplay=='hide'||items==0)
		hide();
	else
		unhide();
});


const minusButtons = document.getElementsByClassName('minusBtn');
for(let i=0; i<minusButtons.length; i++){
	minusButtons[i].addEventListener('click', function(){
		const parent = this.parentNode;
		let count = parseInt(parent.childNodes[3].value);
		if((count-1)>0){
			parent.childNodes[3].value = count-1;
			swap(this.parentNode.childNodes[3].getAttribute('id'));
			computeTotal();
			itemsDecrement();
		}
		else if(count=='1'){
			disable(this.parentNode.childNodes);
			parent.childNodes[3].value = count-1;
			swap(this.parentNode.childNodes[3].getAttribute('id'));
			document.getElementById("cart-image").innerHTML='';
			document.getElementById("cart-total").innerHTML='';
			computeTotal();
			itemsDecrement();
		}
		const num= this.parentNode.childNodes[3].getAttribute('id').substr(1);
		storeData(num-1,parent.childNodes[3].value);

		if(!itemCount()){
		
			hide();
			localStorage.setItem("cartDisplay","hide");
			localStorage.setItem('cartStatus','deactivated');
			localStorage.setItem('overlay','none');
			document.getElementById('overlay').style.display='none';

		
		}
	});
}

const plusButtons = document.getElementsByClassName('plusBtn');
for(let i =0; i <plusButtons.length; i++){
	plusButtons[i].addEventListener('click',function(){
		const parent = this.parentNode;
		let count = parseInt(parent.childNodes[3].value);
		if(count==0){
			enable(this.parentNode.childNodes);
		}
		if(count<100){
			parent.childNodes[3].value = count+1;
			computeTotal();
			itemsIncrement();
		}
		swap(this.parentNode.childNodes[3].getAttribute('id'));
		const num= this.parentNode.childNodes[3].getAttribute('id').substr(1);
		storeData(num-1,parent.childNodes[3].value);

	});
}

function computeTotal(){		
	const totalCard = document.getElementById("cart-image");
	totalCard.innerHTML='';

	const totalhead = document.getElementById("cart-head");
	const totalCount = document.getElementById("cart-total");

	let fruitPrice = 0n;
	
	const allFruits = document.getElementsByClassName("product");
	const allFruitQuantity = document.getElementsByClassName("textBox");

	let html='';
	let html3='';
	let productCount=0;
	for(let i=0; i<allFruits.length; i++){
		const str = allFruits[i].childNodes[5].textContent;
		const quantity = allFruitQuantity[i].value;
		let fruitId = allFruits[i].getAttribute('id').substr(1);
		if(quantity>0){
			productCount++;
			const img = allFruits[i].childNodes[3];
			const imgCart = document.createElement("img");
			imgCart.src = img.src;
			let itemCost = BigInt(allFruits[i].childNodes[7].childNodes[3].value)*BigInt(allFruits[i].childNodes[5].textContent.substr(7));
			fruitPrice += itemCost
			html+=`
				<div class= "checkout">
					<img src="${img.src}">
					<p>Total:</p>
					<div class= "quantity">
						<button class="minusBtn outLine">-</button>
						<input type="text" class="textBoxC" id="c${fruitId}" value=${allFruits[i].childNodes[7].childNodes[3].value}>
						<button class="plusBtn outLine">+</button>
					</div>
					<p>Rs.${itemCost}</p>
					<button class="clearItem"><img src="./images/OIP (2).jpg" alt="Description of the image" class="clearImg"></button>
				</div>
			`;
		}
	}


	html3+=`
		<p>Total: Rs.${fruitPrice}</p>
	`;
	
	totalCard.innerHTML=html;
	totalCount.innerHTML=html3;
	check();
	const ele5 = document.getElementById("cart-head");
}

function check(){
	const all = document.querySelectorAll('.checkout');
	
	const checkOutMinus = document.querySelectorAll('.checkout .quantity .minusBtn');
	const checkOutPlus  = document.querySelectorAll('.checkout .quantity .plusBtn');

	checkOutMinus.forEach(btn=>{
		btn.addEventListener('click',function(){
			const textInput = this.parentNode.childNodes[3];
			let count = parseInt(textInput.value);
			if((count-1)>0){
				textInput.value = count-1;
				swap(this.parentNode.childNodes[3].getAttribute('id'));
				computeTotal();
				itemsDecrement();
			}
			else if(count=='1'){
				disableCheckout(this.parentNode.childNodes[3].getAttribute('id'));
				textInput.value = count-1;
				swap(this.parentNode.childNodes[3].getAttribute('id'));
				document.getElementById("cart-image").innerHTML='';
				document.getElementById("cart-total").innerHTML='';
				computeTotal();
				itemsDecrement();
			}
			const num= this.parentNode.childNodes[3].getAttribute('id').substr(1);
			storeData(num-1,this.parentNode.childNodes[3].value);
			
			if(!itemCount()){
			hide();
			localStorage.setItem("cartDisplay","hide");
			localStorage.setItem('cartStatus','deactivated');
			localStorage.setItem('overlay','none');
			document.getElementById('overlay').style.display='none';
			}

		});
	});
	
	checkOutPlus.forEach(btn=>{
		btn.addEventListener('click',function(){
			const textInput = this.parentNode.childNodes[3];
			let count = parseInt(textInput.value);
			if(count==1){
				
			}

			if(count<100){
				textInput.value = count+1;
				swap(this.parentNode.childNodes[3].getAttribute('id'));
				computeTotal();
				itemsIncrement();
			}
			const num= this.parentNode.childNodes[3].getAttribute('id').substr(1);
			storeData(num-1,this.parentNode.childNodes[3].value);
		});

	});
	
	
	const checkOutText  = document.querySelectorAll('.checkout .quantity .textBoxC');
	checkOutText.forEach(txt =>{
		txt.addEventListener('keydown',checkBack2);
	});



}

function swap(str){
	const checkOutText = document.getElementById(`c${str.substr(1)}`);
	const cartText = document.getElementById(`a${str.substr(1)}`);
	if(str.charAt(0)=='c'){
		cartText.value = checkOutText.value;
	}else{
		checkOutText.value = cartText.value;
	}
}


function inputQuant(event){
		event.preventDefault();
}


function checkBack(event){
		event.preventDefault();
}

function checkBack2(event){
		event.preventDefault();
}


const allInputs= document.querySelectorAll('.textBox');
allInputs.forEach(txt =>{
	txt.addEventListener('keypress',inputQuant);

	txt.addEventListener('keydown',checkBack);

});

document.getElementById('deleteBtn').addEventListener('click',function(){
	hide();
	
	
	localStorage.setItem("cartDisplay","hide");
	localStorage.setItem('cartStatus','deactivated');
	localStorage.setItem('overlay','none');
	document.getElementById('overlay').style.display='none';

	
	
	localStorage.setItem("cartDisplay","hide");
	productQuant = Array(12).fill(0);
	localStorage.setItem("cartInfo",productQuant);
	items=0;	
	const count=document.getElementById("cartCount");
	count.innerHTML="";
	const buttons = document.getElementsByClassName('textBox');
	for(i=0;i<buttons.length;i++){
		buttons[i].value=0;
	}
	
	const minusBtn = document.querySelectorAll('.minusBtn');
	minusBtn.forEach(btn => {
			btn.disabled=true;
	});


});


function itemCount(){
	const allFruits = document.getElementsByClassName("product");
	const allFruitQuantity = document.getElementsByClassName("textBox");
	let productCount=0;
	for(let i=0; i<allFruits.length; i++){
		const str = allFruits[i].childNodes[5].textContent;
		const quantity = allFruitQuantity[i].value;
		if(quantity>0){
			productCount++;
		}
	}
	return productCount>0;
}

document.getElementById('cartBtn').addEventListener('click',function(){
	event.stopPropagation();
	
	const ele = document.getElementById("cart-head");
	if(window.getComputedStyle(ele).getPropertyValue('display')=='none'&&itemCount()){
		unhide();
		localStorage.setItem('cartStatus','activated');
		localStorage.setItem("cartDisplay","unhide");
		localStorage.setItem('overlay','block');
		document.getElementById('overlay').style.display='block';
	}else{
		hide();
		localStorage.setItem("cartDisplay","hide");
		localStorage.setItem('cartStatus','deactivated');
		localStorage.setItem('overlay','none');
		document.getElementById('overlay').style.display='none';	
	}
});

function hide(){
	document.getElementById("cart-head").style.display='none';
	document.getElementById("cart-image").style.display='none';
	document.getElementById("cart-total").style.display='none';

}
function unhide(){
	document.getElementById("cart-head").style.display='flex';
	document.getElementById("cart-image").style.display='flex';
	document.getElementById("cart-total").style.display='block';
}

(function(){
	const minusBtn = document.querySelectorAll('.minusBtn');
	minusBtn.forEach(btn => {
			btn.disabled=true;
	});
})();

function disable(childNodes){
	childNodes[1].disabled=true;
}
function disableCheckout(str){
	const cartText = document.getElementById(`a${str.substr(1)}`);
	const btn = cartText.parentNode.childNodes[1];
	btn.disabled=true;
}
function enable(childNodes){
	childNodes[1].disabled=false;
}


function valid(num){
	return /^[0-9]$/.test(num);
}

function storeData(id,val){
	let str = localStorage.getItem("cartInfo");
	let arrStr = str.split(',');
	let arr = [];
	for(let i=0; i<arrStr.length;i++){
		arr.push(parseInt(arrStr[i]));
	}
	arr[id]=val;
	localStorage.setItem("cartInfo",arr);
}

function itemsDecrement(){
	items--;	
	const count=document.getElementById("cartCount");
	if(items==0)
		count.innerHTML="";
	else
		count.innerHTML=items;
		
}

function itemsIncrement(){
	items++;
	const count=document.getElementById("cartCount");
	count.innerHTML=items;

}

document.addEventListener('keydown', function(event) {
  if (event.key === 'Tab') {
    event.preventDefault();
  }
});

document.addEventListener("DOMContentLoaded", function() {
    let body = document.body;

    body.addEventListener("click", function(event) {
	let status = localStorage.getItem('cartStatus');
	if(status=='activated'){

		let cartContainer = document.getElementById("cartTotal");
       		let isClickInsideCart = cartContainer.contains(event.target);
	
		const bool1 = event.target.classList.contains('clearImg');
		const bool2 = event.target.classList.contains('clearItem');
		const bool3 = event.target.classList.contains('outLine');
		if(!(isClickInsideCart||bool1||bool2||bool3)){
			const overLap = document.getElementById('overlay');
			overLap.style.display="none";
			
			localStorage.setItem('cartStatus','deactivated');

			const ele = document.getElementById("cart-head");
			
			hide();
			localStorage.setItem("cartDisplay","hide");
			localStorage.setItem("overlay","none");

		}
	}


    });
});

document.addEventListener('DOMContentLoaded',function(){
	document.getElementById('cart-image').addEventListener('click',function(event){
		if(event.target.closest('.clearItem')){
			const checkout= event.target.closest('.checkout');
			const quant = checkout.querySelector('.quantity');
			const textbox = checkout.querySelector('.textBoxC');
			const id = textbox.getAttribute('id').substr(1);
			const textbox2 = document.getElementById(`a${id}`);
			const divBox = textbox2.closest('.quantity');
			const btn = divBox.querySelector('.minusBtn');
			btn.disabled=true;
			textbox2.value=0;
			
			const arr = localStorage.getItem('cartInfo');
			const arr2 = arr.split(',').map(ele=>parseInt(ele));
			arr2[id-1] = 0;
			localStorage.setItem('cartInfo',arr2);
			const itemsCount = arr2.reduce((total,ele) => total+ele,0);
			items = itemsCount;
			if(itemsCount>0)
			document.getElementById('cartCount').innerHTML=itemsCount;
			else
			document.getElementById('cartCount').innerHTML='';
			computeTotal();
			
			if(!itemCount()){
		
				hide();
				localStorage.setItem("cartDisplay","hide");
				localStorage.setItem('cartStatus','deactivated');
				localStorage.setItem('overlay','none');
				document.getElementById('overlay').style.display='none';
			}
			
		}
	});
});

